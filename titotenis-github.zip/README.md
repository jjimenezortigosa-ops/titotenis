# TitoTenis

Web de tenis ATP y WTA: noticias, partidos, previas y foro.

Archivos: index.html (la web), data.json (datos que se actualizan), fotos.json (fotos con crédito).
